package com.example.c4project;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
