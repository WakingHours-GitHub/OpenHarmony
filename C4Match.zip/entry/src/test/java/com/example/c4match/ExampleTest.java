package com.example.c4match;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
