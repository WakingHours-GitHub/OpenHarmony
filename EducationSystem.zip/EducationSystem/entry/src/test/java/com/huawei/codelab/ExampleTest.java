package com.huawei.codelab;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
