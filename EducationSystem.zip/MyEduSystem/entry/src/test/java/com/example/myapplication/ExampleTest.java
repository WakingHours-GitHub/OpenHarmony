package com.example.myapplication;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
